﻿using BepInEx;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEngine;
using UnityEngine.Networking;

namespace keysys
{
    [BepInPlugin("keysystem", "keysys", "1.0.0")]
    internal class KeySystem : BaseUnityPlugin
    {
        // Original KeySystem variables
        private Dictionary<string, string> keyHWIDPairs = new Dictionary<string, string>();
        private string enteredCode = "";
        private string redeemMessage = "";
        private bool show = true;
        public static bool key = false;
        private bool initialized = false;
        private string currentHWID = "";
        private string webhookURL = "";

        // Modern GUI variables
        private bool showMenu = false;
        private int currentTab = 0; // 0 = Key System, 1 = Modules, 2 = Settings
        private string searchText = "";
        private Vector2 scrollPosition = Vector2.zero;

        // Window properties
        private Rect windowRect = new Rect(100, 100, 800, 600);
        private bool isDragging = false;
        private Vector2 dragOffset;

        // Colors and styling
        private Color backgroundColor = new Color(0.1f, 0.12f, 0.15f, 0.95f);
        private Color sidebarColor = new Color(0.08f, 0.1f, 0.12f, 1f);
        private Color accentColor = new Color(0.2f, 0.8f, 0.9f, 1f);
        private Color buttonColor = new Color(0.15f, 0.18f, 0.22f, 1f);
        private Color textColor = new Color(0.9f, 0.95f, 1f, 1f);

        // Module system
        private List<ModuleInfo> modules = new List<ModuleInfo>();
        private Dictionary<string, bool> moduleStates = new Dictionary<string, bool>();

        // Settings
        private bool setting1 = false;
        private bool setting2 = true;
        private float sliderValue = 0.5f;

        // Textures (created at runtime)
        private Texture2D whiteTexture;
        private GUIStyle customButtonStyle;
        private GUIStyle sidebarButtonStyle;
        private GUIStyle searchStyle;

        private string[] keys = new string[]
        {
            "FREEMENU", "E"
        };

        private string[] Adminkeys = new string[]
        {
            "g3if-ADMIN-8824", "FOUNDER-FEL-3710184"
        };

        private void Start()
        {
            currentHWID = GenerateHWID();
            LoadKeyBindings();
            InitializeTextures();
            InitializeStyles();
            InitializeModules();
        }

        private void Update()
        {
            // Toggle menu with Ctrl key
            if (Input.GetKeyDown(KeyCode.LeftControl) || Input.GetKeyDown(KeyCode.RightControl))
            {
                showMenu = !showMenu;
            }

            // Close menu with Escape
            if (showMenu && Input.GetKeyDown(KeyCode.Escape))
            {
                showMenu = false;
            }
        }

        private string GenerateHWID()
        {
            try
            {
                string hwid = "";
                hwid += SystemInfo.deviceUniqueIdentifier;
                hwid += SystemInfo.processorType;
                hwid += SystemInfo.graphicsDeviceName;
                hwid += SystemInfo.systemMemorySize.ToString();
                hwid += System.Environment.MachineName;
                hwid += System.Environment.UserName;

                using (var sha256 = System.Security.Cryptography.SHA256.Create())
                {
                    byte[] hashedBytes = sha256.ComputeHash(System.Text.Encoding.UTF8.GetBytes(hwid));
                    return System.Convert.ToBase64String(hashedBytes).Substring(0, 16);
                }
            }
            catch
            {
                return SystemInfo.deviceUniqueIdentifier.Substring(0, Math.Min(16, SystemInfo.deviceUniqueIdentifier.Length));
            }
        }

        void InitializeTextures()
        {
            whiteTexture = new Texture2D(1, 1);
            whiteTexture.SetPixel(0, 0, Color.white);
            whiteTexture.Apply();
        }

        void InitializeStyles()
        {
            customButtonStyle = new GUIStyle(GUI.skin.button);
            customButtonStyle.normal.background = MakeTexture(1, 1, buttonColor);
            customButtonStyle.hover.background = MakeTexture(1, 1, buttonColor * 1.2f);
            customButtonStyle.normal.textColor = textColor;
            customButtonStyle.hover.textColor = Color.white;
            customButtonStyle.fontSize = 12;
            customButtonStyle.border = new RectOffset(4, 4, 4, 4);

            sidebarButtonStyle = new GUIStyle(GUI.skin.button);
            sidebarButtonStyle.normal.background = MakeTexture(1, 1, Color.clear);
            sidebarButtonStyle.hover.background = MakeTexture(1, 1, accentColor * 0.3f);
            sidebarButtonStyle.active.background = MakeTexture(1, 1, accentColor);
            sidebarButtonStyle.normal.textColor = textColor;
            sidebarButtonStyle.hover.textColor = Color.white;
            sidebarButtonStyle.fontSize = 14;
            sidebarButtonStyle.alignment = TextAnchor.MiddleLeft;
            sidebarButtonStyle.border = new RectOffset(4, 4, 4, 4);
            sidebarButtonStyle.padding = new RectOffset(20, 10, 10, 10);

            searchStyle = new GUIStyle(GUI.skin.textField);
            searchStyle.normal.background = MakeTexture(1, 1, buttonColor);
            searchStyle.normal.textColor = textColor;
            searchStyle.fontSize = 12;
            searchStyle.border = new RectOffset(4, 4, 4, 4);
            searchStyle.padding = new RectOffset(10, 10, 8, 8);
        }

        void InitializeModules()
        {
            // Example modules - replace these with your actual game modules
            modules.Add(new ModuleInfo("Player Speed", "Movement", "Increases player movement speed", false));
            modules.Add(new ModuleInfo("Jump Height", "Movement", "Modifies jump height", false));
            modules.Add(new ModuleInfo("No Fall Damage", "Player", "Prevents fall damage", false));
            modules.Add(new ModuleInfo("Infinite Health", "Player", "Unlimited health points", false));
            modules.Add(new ModuleInfo("Fast Mining", "Tools", "Increases mining speed", false));
            modules.Add(new ModuleInfo("Auto Collection", "Tools", "Automatically collects items", false));
            modules.Add(new ModuleInfo("Night Vision", "Visual", "See clearly in dark areas", false));
            modules.Add(new ModuleInfo("ESP Players", "Visual", "See players through walls", false));
            modules.Add(new ModuleInfo("Inventory Manager", "Utility", "Advanced inventory features", false));
            modules.Add(new ModuleInfo("Teleportation", "Utility", "Quick travel system", false));

            // Initialize module states
            foreach (var module in modules)
            {
                moduleStates[module.name] = module.enabled;
            }
        }

        private void OnGUI()
        {
            // Show original key system if not authenticated and show is true
            if (!key && show)
            {
                DrawOriginalKeySystem();
                return;
            }

            // Show modern menu if authenticated and menu is toggled
            if (!showMenu || !key) return;

            GUI.color = Color.white;

            // Draw main window background
            GUI.color = backgroundColor;
            GUI.DrawTexture(windowRect, whiteTexture);
            GUI.color = Color.white;

            // Handle window dragging
            HandleWindowDragging();

            // Draw border
            DrawBorder(windowRect, 2f, accentColor);

            // Draw sidebar
            DrawSidebar();

            // Draw main content
            DrawMainContent();

            // Draw top bar
            DrawTopBar();
        }

        private void DrawOriginalKeySystem()
        {
            if (!initialized)
            {
                Vector2 windowTargetPos = new Vector2((Screen.width - 400) / 2f, (Screen.height - 280) / 2f);
                windowRect = new Rect(windowTargetPos.x, windowTargetPos.y, 400, 280);
                initialized = true;
            }

            // Background overlay
            GUI.color = new Color(0f, 0f, 0f, 0.75f);
            GUI.DrawTexture(new Rect(0, 0, Screen.width, Screen.height), whiteTexture);
            GUI.color = Color.white;

            // Window background
            GUI.color = new Color(0.1f, 0.1f, 0.15f, 0.95f);
            GUI.DrawTexture(windowRect, whiteTexture);

            // Window border
            GUI.color = new Color(0.3f, 0.7f, 1f, 0.8f);
            DrawBorder(windowRect, 2f, GUI.color);

            GUI.color = Color.white;

            // Title
            GUIStyle titleStyle = new GUIStyle();
            titleStyle.fontSize = 24;
            titleStyle.fontStyle = FontStyle.Bold;
            titleStyle.alignment = TextAnchor.MiddleCenter;
            titleStyle.normal.textColor = new Color(0.8f, 0.9f, 1f);

            GUI.Label(new Rect(windowRect.x + 20, windowRect.y + 15, windowRect.width - 40, 30),
                     "Client.gg", titleStyle);

            // Input field
            Rect inputRect = new Rect(windowRect.x + 30, windowRect.y + 70, windowRect.width - 60, 35);

            GUI.color = new Color(0.15f, 0.15f, 0.25f, 0.9f);
            GUI.DrawTexture(inputRect, whiteTexture);

            GUI.color = new Color(0.4f, 0.7f, 1f, 0.6f);
            DrawBorder(inputRect, 1f, GUI.color);

            GUIStyle inputStyle = new GUIStyle(GUI.skin.textField);
            inputStyle.fontSize = 14;
            inputStyle.alignment = TextAnchor.MiddleCenter;
            inputStyle.normal.textColor = Color.white;
            inputStyle.normal.background = MakeTexture(1, 1, Color.clear);
            inputStyle.focused.background = MakeTexture(1, 1, Color.clear);

            GUI.color = Color.white;
            GUILayout.BeginArea(inputRect);
            enteredCode = GUILayout.TextField(enteredCode.ToUpper(), inputStyle, GUILayout.Height(35));
            GUILayout.EndArea();

            // Button
            Rect buttonRect = new Rect(windowRect.x + 30, windowRect.y + 125, windowRect.width - 60, 40);

            GUI.color = new Color(0.2f, 0.5f, 0.8f, 0.8f);
            GUI.DrawTexture(buttonRect, whiteTexture);

            GUI.color = new Color(0.4f, 0.8f, 1f, 0.9f);
            DrawBorder(buttonRect, 1f, GUI.color);

            GUIStyle buttonStyle = new GUIStyle();
            buttonStyle.fontSize = 16;
            buttonStyle.fontStyle = FontStyle.Bold;
            buttonStyle.alignment = TextAnchor.MiddleCenter;
            buttonStyle.normal.textColor = Color.white;

            GUI.color = Color.white;
            if (GUI.Button(buttonRect, "", GUIStyle.none))
                ValidateKey();

            GUI.Label(buttonRect, "ENTER", buttonStyle);

            // Message
            if (!string.IsNullOrEmpty(redeemMessage))
            {
                GUIStyle messageStyle = new GUIStyle();
                messageStyle.fontSize = 12;
                messageStyle.alignment = TextAnchor.MiddleCenter;

                if (redeemMessage.Contains("INVALID"))
                    messageStyle.normal.textColor = Color.red;
                else if (redeemMessage.Contains("GRANTED"))
                    messageStyle.normal.textColor = Color.green;
                else
                    messageStyle.normal.textColor = new Color(0.8f, 0.9f, 1f);

                GUI.Label(new Rect(windowRect.x + 20, windowRect.y + 185, windowRect.width - 40, 20),
                         redeemMessage, messageStyle);
            }

            // Status indicator
            Vector2 statusPos = new Vector2(windowRect.x + windowRect.width - 20, windowRect.y + 10);
            Color statusColor = key ? Color.green : new Color(0.3f, 0.7f, 1f);
            GUI.color = statusColor;
            GUI.DrawTexture(new Rect(statusPos.x, statusPos.y, 8, 8), whiteTexture);
            GUI.color = Color.white;
        }

        void HandleWindowDragging()
        {
            Rect titleBar = new Rect(windowRect.x + 180, windowRect.y, windowRect.width - 180, 50);

            if (Event.current.type == EventType.MouseDown && titleBar.Contains(Event.current.mousePosition))
            {
                isDragging = true;
                dragOffset = Event.current.mousePosition - new Vector2(windowRect.x, windowRect.y);
            }
            else if (Event.current.type == EventType.MouseUp)
            {
                isDragging = false;
            }
            else if (isDragging && Event.current.type == EventType.MouseDrag)
            {
                Vector2 newPos = Event.current.mousePosition - dragOffset;
                windowRect.x = newPos.x;
                windowRect.y = newPos.y;
            }
        }

        void DrawSidebar()
        {
            Rect sidebarRect = new Rect(windowRect.x, windowRect.y, 180, windowRect.height);

            // Sidebar background
            GUI.color = sidebarColor;
            GUI.DrawTexture(sidebarRect, whiteTexture);
            GUI.color = Color.white;

            // Logo
            Rect logoRect = new Rect(sidebarRect.x + 10, sidebarRect.y + 10, sidebarRect.width - 20, 40);
            GUIStyle logoStyle = new GUIStyle();
            logoStyle.fontSize = 20;
            logoStyle.fontStyle = FontStyle.Bold;
            logoStyle.normal.textColor = accentColor;
            logoStyle.alignment = TextAnchor.MiddleCenter;
            GUI.Label(logoRect, "Untitled", logoStyle);

            // Tab buttons
            float buttonY = sidebarRect.y + 80;
            float buttonHeight = 45;

            string[] tabNames = { "🔑 Auth", "📋 Modules", "⚙️ Settings" };

            for (int i = 0; i < tabNames.Length; i++)
            {
                Rect buttonRect = new Rect(sidebarRect.x + 5, buttonY, sidebarRect.width - 10, buttonHeight);

                GUIStyle style = new GUIStyle(sidebarButtonStyle);
                if (currentTab == i)
                {
                    style.normal.background = MakeTexture(1, 1, accentColor * 0.8f);
                    style.normal.textColor = Color.white;
                }

                if (GUI.Button(buttonRect, tabNames[i], style))
                {
                    currentTab = i;
                    scrollPosition = Vector2.zero;
                }

                buttonY += buttonHeight + 5;
            }

            // Version info at bottom
            Rect versionRect = new Rect(sidebarRect.x + 10, sidebarRect.y + sidebarRect.height - 30, sidebarRect.width - 20, 20);
            GUIStyle versionStyle = new GUIStyle();
            versionStyle.fontSize = 10;
            versionStyle.normal.textColor = textColor * 0.7f;
            versionStyle.alignment = TextAnchor.MiddleCenter;
            GUI.Label(versionRect, "Version 1.0.0", versionStyle);
        }

        void DrawTopBar()
        {
            Rect topBarRect = new Rect(windowRect.x + 180, windowRect.y, windowRect.width - 180, 50);

            // Top bar background
            GUI.color = sidebarColor;
            GUI.DrawTexture(topBarRect, whiteTexture);
            GUI.color = Color.white;

            // Search bar (only show on modules tab)
            if (currentTab == 1)
            {
                Rect searchRect = new Rect(topBarRect.x + 20, topBarRect.y + 10, 200, 30);
                searchText = GUI.TextField(searchRect, searchText, searchStyle);

                // Search placeholder
                if (string.IsNullOrEmpty(searchText))
                {
                    GUIStyle placeholderStyle = new GUIStyle();
                    placeholderStyle.normal.textColor = textColor * 0.5f;
                    placeholderStyle.fontSize = 12;
                    placeholderStyle.alignment = TextAnchor.MiddleLeft;
                    GUI.Label(new Rect(searchRect.x + 10, searchRect.y, searchRect.width - 20, searchRect.height), "🔍 Search...", placeholderStyle);
                }
            }

            // Close button
            Rect closeRect = new Rect(topBarRect.x + topBarRect.width - 40, topBarRect.y + 10, 30, 30);
            if (GUI.Button(closeRect, "✕", customButtonStyle))
            {
                showMenu = false;
            }
        }

        void DrawMainContent()
        {
            Rect contentRect = new Rect(windowRect.x + 180, windowRect.y + 50, windowRect.width - 180, windowRect.height - 50);

            // Content background
            GUI.color = backgroundColor;
            GUI.DrawTexture(contentRect, whiteTexture);
            GUI.color = Color.white;

            // Draw content based on current tab
            switch (currentTab)
            {
                case 0:
                    DrawAuthContent(contentRect);
                    break;
                case 1:
                    DrawModulesContent(contentRect);
                    break;
                case 2:
                    DrawSettingsContent(contentRect);
                    break;
            }
        }

        void DrawAuthContent(Rect contentRect)
        {
            GUILayout.BeginArea(new Rect(contentRect.x + 20, contentRect.y + 20, contentRect.width - 40, contentRect.height - 40));

            // Title
            GUIStyle titleStyle = new GUIStyle();
            titleStyle.fontSize = 24;
            titleStyle.fontStyle = FontStyle.Bold;
            titleStyle.normal.textColor = textColor;
            GUILayout.Label("Authentication Status", titleStyle);

            GUILayout.Space(20);

            // Status info
            GUIStyle statStyle = new GUIStyle();
            statStyle.fontSize = 14;
            statStyle.normal.textColor = textColor * 0.9f;

            GUILayout.Label($"Status: {(key ? "Authenticated ✓" : "Not Authenticated")}", statStyle);
            GUILayout.Label($"HWID: {currentHWID}", statStyle);
            GUILayout.Label($"Machine: {System.Environment.MachineName}", statStyle);
            GUILayout.Label($"User: {System.Environment.UserName}", statStyle);

            GUILayout.Space(30);

            if (key)
            {
                GUIStyle successStyle = new GUIStyle();
                successStyle.fontSize = 16;
                successStyle.normal.textColor = Color.green;
                GUILayout.Label("✓ Successfully authenticated! You can now access all features.", successStyle);

                GUILayout.Space(20);

                if (GUILayout.Button("Log Out", customButtonStyle, GUILayout.Height(35), GUILayout.Width(150)))
                {
                    key = false;
                    show = true;
                    showMenu = false;
                    redeemMessage = "";
                    enteredCode = "";
                }
            }

            GUILayout.EndArea();
        }

        void DrawModulesContent(Rect contentRect)
        {
            GUILayout.BeginArea(new Rect(contentRect.x + 20, contentRect.y + 20, contentRect.width - 40, contentRect.height - 40));

            // Title
            GUIStyle titleStyle = new GUIStyle();
            titleStyle.fontSize = 20;
            titleStyle.fontStyle = FontStyle.Bold;
            titleStyle.normal.textColor = textColor;
            GUILayout.Label("Modules", titleStyle);

            GUILayout.Space(15);

            // Category tabs
            string[] categories = { "All", "Movement", "Player", "Tools", "Visual", "Utility" };
            GUILayout.BeginHorizontal();
            foreach (string category in categories)
            {
                if (GUILayout.Button(category, customButtonStyle, GUILayout.Height(30)))
                {
                    // Filter by category logic would go here
                }
            }
            GUILayout.EndHorizontal();

            GUILayout.Space(10);

            // Scrollable module list
            scrollPosition = GUILayout.BeginScrollView(scrollPosition);

            foreach (var module in modules)
            {
                // Filter by search text
                if (!string.IsNullOrEmpty(searchText) &&
                    !module.name.ToLower().Contains(searchText.ToLower()) &&
                    !module.description.ToLower().Contains(searchText.ToLower()))
                {
                    continue;
                }

                DrawModuleItem(module);
            }

            GUILayout.EndScrollView();
            GUILayout.EndArea();
        }

        void DrawModuleItem(ModuleInfo module)
        {
            GUILayout.BeginVertical();

            // Module background
            Rect moduleRect = GUILayoutUtility.GetRect(0, 80, GUILayout.ExpandWidth(true));
            GUI.color = buttonColor;
            GUI.DrawTexture(moduleRect, whiteTexture);
            GUI.color = Color.white;

            GUILayout.BeginArea(moduleRect);
            GUILayout.BeginHorizontal();

            // Module info
            GUILayout.BeginVertical();
            GUILayout.Space(10);

            GUIStyle nameStyle = new GUIStyle();
            nameStyle.fontSize = 14;
            nameStyle.fontStyle = FontStyle.Bold;
            nameStyle.normal.textColor = textColor;
            GUILayout.Label(module.name, nameStyle);

            GUIStyle descStyle = new GUIStyle();
            descStyle.fontSize = 11;
            descStyle.normal.textColor = textColor * 0.8f;
            GUILayout.Label(module.description, descStyle);

            GUIStyle categoryStyle = new GUIStyle();
            categoryStyle.fontSize = 10;
            categoryStyle.normal.textColor = accentColor;
            GUILayout.Label($"Category: {module.category}", categoryStyle);

            GUILayout.EndVertical();

            // Toggle button
            GUILayout.FlexibleSpace();
            GUILayout.BeginVertical();
            GUILayout.Space(15);

            bool currentState = moduleStates[module.name];
            bool newState = GUILayout.Toggle(currentState, currentState ? "ON" : "OFF", customButtonStyle, GUILayout.Width(60), GUILayout.Height(25));

            if (newState != currentState)
            {
                moduleStates[module.name] = newState;
                if (newState)
                {
                    EnableModule(module.name);
                }
                else
                {
                    DisableModule(module.name);
                }
            }

            GUILayout.EndVertical();
            GUILayout.Space(10);

            GUILayout.EndHorizontal();
            GUILayout.EndArea();

            GUILayout.Space(85);
            GUILayout.EndVertical();
        }

        void DrawSettingsContent(Rect contentRect)
        {
            GUILayout.BeginArea(new Rect(contentRect.x + 20, contentRect.y + 20, contentRect.width - 40, contentRect.height - 40));

            scrollPosition = GUILayout.BeginScrollView(scrollPosition);

            // Title
            GUIStyle titleStyle = new GUIStyle();
            titleStyle.fontSize = 20;
            titleStyle.fontStyle = FontStyle.Bold;
            titleStyle.normal.textColor = textColor;
            GUILayout.Label("Settings", titleStyle);

            GUILayout.Space(20);

            // General Settings
            DrawSettingsSection("General Settings");
            setting1 = DrawToggleSetting("Enable Notifications", "Show system notifications", setting1);
            setting2 = DrawToggleSetting("Auto-Save Configuration", "Automatically save settings", setting2);

            GUILayout.Space(15);

            // UI Settings
            DrawSettingsSection("Interface Settings");
            GUILayout.BeginHorizontal();
            GUILayout.Label("UI Scale:", GUILayout.Width(100));
            sliderValue = GUILayout.HorizontalSlider(sliderValue, 0.5f, 2.0f);
            GUILayout.Label($"{sliderValue:F1}x", GUILayout.Width(40));
            GUILayout.EndHorizontal();

            GUILayout.Space(20);

            // Action buttons
            DrawSettingsSection("Actions");
            GUILayout.BeginHorizontal();
            if (GUILayout.Button("Save Settings", customButtonStyle, GUILayout.Height(35)))
            {
                SaveSettings();
            }
            if (GUILayout.Button("Load Defaults", customButtonStyle, GUILayout.Height(35)))
            {
                LoadDefaultSettings();
            }
            GUILayout.EndHorizontal();

            GUILayout.EndScrollView();
            GUILayout.EndArea();
        }

        void DrawSettingsSection(string title)
        {
            GUIStyle sectionStyle = new GUIStyle();
            sectionStyle.fontSize = 16;
            sectionStyle.fontStyle = FontStyle.Bold;
            sectionStyle.normal.textColor = accentColor;
            GUILayout.Label(title, sectionStyle);
            GUILayout.Space(5);
        }

        bool DrawToggleSetting(string label, string description, bool currentValue)
        {
            GUILayout.BeginHorizontal();
            bool newValue = GUILayout.Toggle(currentValue, "", GUILayout.Width(20));

            GUILayout.BeginVertical();
            GUIStyle labelStyle = new GUIStyle();
            labelStyle.fontSize = 13;
            labelStyle.normal.textColor = textColor;
            GUILayout.Label(label, labelStyle);

            GUIStyle descStyle = new GUIStyle();
            descStyle.fontSize = 10;
            descStyle.normal.textColor = textColor * 0.7f;
            GUILayout.Label(description, descStyle);
            GUILayout.EndVertical();

            GUILayout.EndHorizontal();
            GUILayout.Space(5);

            return newValue;
        }

        void DrawBorder(Rect rect, float thickness, Color color)
        {
            GUI.color = color;
            // Top
            GUI.DrawTexture(new Rect(rect.x, rect.y, rect.width, thickness), whiteTexture);
            // Bottom
            GUI.DrawTexture(new Rect(rect.x, rect.y + rect.height - thickness, rect.width, thickness), whiteTexture);
            // Left
            GUI.DrawTexture(new Rect(rect.x, rect.y, thickness, rect.height), whiteTexture);
            // Right
            GUI.DrawTexture(new Rect(rect.x + rect.width - thickness, rect.y, thickness, rect.height), whiteTexture);
            GUI.color = Color.white;
        }

        Texture2D MakeTexture(int width, int height, Color color)
        {
            Color[] pixels = new Color[width * height];
            for (int i = 0; i < pixels.Length; i++)
            {
                pixels[i] = color;
            }

            Texture2D texture = new Texture2D(width, height);
            texture.SetPixels(pixels);
            texture.Apply();
            return texture;
        }

        // Module control methods
        void EnableModule(string moduleName)
        {
            Debug.Log($"Enabling module: {moduleName}");
            // Add your module enable logic here
        }

        void DisableModule(string moduleName)
        {
            Debug.Log($"Disabling module: {moduleName}");
            // Add your module disable logic here
        }

        // Settings methods
        void SaveSettings()
        {
            Debug.Log("Saving settings...");
            PlayerPrefs.SetInt("Setting1", setting1 ? 1 : 0);
            PlayerPrefs.SetInt("Setting2", setting2 ? 1 : 0);
            PlayerPrefs.SetFloat("UIScale", sliderValue);
            PlayerPrefs.Save();
        }

        void LoadDefaultSettings()
        {
            Debug.Log("Loading default settings...");
            setting1 = false;
            setting2 = true;
            sliderValue = 1.0f;
        }

        // Original KeySystem methods
        private void ValidateKey()
        {
            if (string.IsNullOrWhiteSpace(enteredCode))
            {
                redeemMessage = "KEY REQUIRED";
                return;
            }

            string cleanCode = enteredCode.Trim().ToUpper();
            bool keyExists = keys.Contains(cleanCode) || Adminkeys.Contains(cleanCode);

            if (!keyExists)
            {
                redeemMessage = "INVALID KEY";
                StartCoroutine(SendWebhook(cleanCode, currentHWID, "INVALID_KEY", "Invalid key attempted"));
                return;
            }

            if (keyHWIDPairs.ContainsKey(cleanCode))
            {
                if (keyHWIDPairs[cleanCode] == currentHWID)
                {
                    redeemMessage = "ACCESS GRANTED";
                    key = true;
                    StartCoroutine(SendWebhook(cleanCode, currentHWID, "RE_AUTH_SUCCESS", "Key re-authenticated successfully"));
                    StartCoroutine(CloseWindow());
                }
                else
                {
                    redeemMessage = "KEY BOUND TO ANOTHER DEVICE";
                    StartCoroutine(SendWebhook(cleanCode, currentHWID, "UNAUTHORIZED_ATTEMPT",
                        "Key bound to " + keyHWIDPairs[cleanCode].Substring(0, 8) + "... but used by " + currentHWID.Substring(0, 8) + "..."));
                }
            }
            else
            {
                keyHWIDPairs[cleanCode] = currentHWID;
                redeemMessage = "KEY BOUND & ACCESS GRANTED";
                key = true;

                StartCoroutine(SendWebhook(cleanCode, currentHWID, "NEW_KEY_BOUND", "Key bound to new HWID for first time"));
                SaveKeyBindings();
                StartCoroutine(CloseWindow());
            }
        }

        private void SaveKeyBindings()
        {
            try
            {
                string serializedData = "";
                foreach (var pair in keyHWIDPairs)
                {
                    serializedData += pair.Key + ":" + pair.Value + ";";
                }
                PlayerPrefs.SetString("UntitledKeyBindings", serializedData);
                PlayerPrefs.Save();
            }
            catch (System.Exception e)
            {
                Debug.LogError("Failed to save key bindings: " + e.Message);
            }
        }

        private void LoadKeyBindings()
        {
            try
            {
                string serializedData = PlayerPrefs.GetString("UntitledKeyBindings", "");
                if (!string.IsNullOrEmpty(serializedData))
                {
                    string[] pairs = serializedData.Split(';');
                    foreach (string pair in pairs)
                    {
                        if (!string.IsNullOrEmpty(pair) && pair.Contains(":"))
                        {
                            string[] parts = pair.Split(':');
                            if (parts.Length == 2)
                            {
                                keyHWIDPairs[parts[0]] = parts[1];
                            }
                        }
                    }
                }
            }
            catch (System.Exception e)
            {
                Debug.LogError("Failed to load key bindings: " + e.Message);
            }
        }

        private IEnumerator SendWebhook(string keyUsed, string hwid, string eventType, string description)
        {
            string jsonPayload = "{\n" +
                "  \"embeds\": [\n" +
                "    {\n" +
                "      \"title\": \"Client.gg Key System Event\",\n" +
                "      \"color\": " + GetEventColor(eventType) + ",\n" +
                "      \"description\": \"**Event:** " + eventType + "\\n" +
                                      "**Key:** `" + keyUsed + "`\\n" +
                                      "**HWID:** `" + hwid + "`\\n" +
                                      "**Description:** " + description + "\\n" +
                                      "**Time:** " + System.DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss UTC") + "\\n" +
                                      "**Machine:** " + System.Environment.MachineName + " (" + System.Environment.UserName + ")" + "\",\n" +
                "      \"footer\": {\n" +
                "        \"text\": \"Xenon Key System v2.1\"\n" +
                "      }\n" +
                "    }\n" +
                "  ]\n" +
                "}";

            UnityEngine.Networking.UnityWebRequest www = null;
            try
            {
                www = new UnityEngine.Networking.UnityWebRequest(webhookURL, "POST");
                byte[] bodyRaw = System.Text.Encoding.UTF8.GetBytes(jsonPayload);
                www.uploadHandler = new UnityEngine.Networking.UploadHandlerRaw(bodyRaw);
                www.downloadHandler = new UnityEngine.Networking.DownloadHandlerBuffer();
                www.SetRequestHeader("Content-Type", "application/json");
            }
            catch (System.Exception e)
            {
                Debug.LogError("Webhook error: " + e.Message);
                yield break;
            }

            yield return www.SendWebRequest();

            if (www.result != UnityEngine.Networking.UnityWebRequest.Result.Success)
            {
                Debug.LogWarning("Webhook failed: " + www.error);
            }
            else
            {
                Debug.Log("Webhook sent successfully");
            }
        }

        private int GetEventColor(string eventType)
        {
            switch (eventType)
            {
                case "NEW_KEY_BOUND":
                    return 0x00ff00;
                case "RE_AUTH_SUCCESS":
                    return 0x0099ff;
                case "UNAUTHORIZED_ATTEMPT":
                    return 0xff9900;
                case "INVALID_KEY":
                    return 0xff0000;
                default:
                    return 0x888888;
            }
        }

        private IEnumerator CloseWindow()
        {
            yield return new WaitForSeconds(1.5f);
            show = false;
            redeemMessage = "";
            enteredCode = "";
        }

        void OnDestroy()
        {
            if (whiteTexture != null)
                DestroyImmediate(whiteTexture);
            StopAllCoroutines();
        }
    }

    // Data structure for modules
    [System.Serializable]
    public class ModuleInfo
    {
        public string name;
        public string category;
        public string description;
        public bool enabled;

        public ModuleInfo(string name, string category, string description, bool enabled)
        {
            this.name = name;
            this.category = category;
            this.description = description;
            this.enabled = enabled;
        }
    }
}