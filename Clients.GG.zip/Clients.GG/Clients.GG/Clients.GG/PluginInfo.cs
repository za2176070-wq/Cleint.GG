﻿namespace StupidTemplate
{
    internal class PluginInfo
    {
        public const string GUID = "org.iidk.gorillatag.menutemplate";
        public const string Name = "ii's Stupid Template";
        public const string Description = "Created by @goldentrophy with love <3";
        public const string Version = "1.0.0";
    }
}
